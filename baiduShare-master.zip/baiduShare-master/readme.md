﻿# 百度分享不支持Https的解决方案  #
## 使用方法： ##
将其static文件夹放在网站的根目录下，并将对应的百度分享代码中，把http://bdimg.share.baidu.com/改为 /


## 更新日志 ##
### 2016.7.9 ###
1.修复URL过长导致微信分享二维码显示不出的问题
2.微信分享外观微调



### 如何修改获得该代码等详见Blog： ###
https://blog.ediandian.org